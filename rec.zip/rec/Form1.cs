﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace CollapseShapes
{
    public partial class Form1 : Form
    {
        private RectangleF rectangle1;
        private RectangleF rectangle2;
        private float dx1, dx2;
        private float weight1, weight2;
        private int collapses;
        private Stopwatch stopwatch;
        private Thread updateThread;

        public Form1()
        {
            InitializeComponent();
            this.rectangle1 = new RectangleF(50, 100, 100, 100);
            this.rectangle2 = new RectangleF(200, 100, 100, 100);
            this.dx1 = 0; // Horizontal movement speed for rectangle1
            this.dx2 = -0.005f; // Horizontal movement speed for rectangle2
            this.weight1 = 1; // Weight for rectangle1
            this.weight2 = 100000000; // Weight for rectangle2
            this.collapses = 0;
            this.Paint += new PaintEventHandler(Form1_Paint);
            InitializeStopwatch();
        }

        private void InitializeStopwatch()
        {
            stopwatch = new Stopwatch();
            stopwatch.Start();
            updateThread = new Thread(UpdateLoop);
            updateThread.IsBackground = true;
            updateThread.Start();
        }
        

        private void UpdateLoop()
        {
            while (true)
            {
                //Thread.Sleep(1); // Sleep for 1 millisecond to prevent excessive CPU usage
                if (stopwatch.Elapsed.TotalMilliseconds >= 0.1) // Check every 0.1 milliseconds
                {
                    stopwatch.Restart();
                    Timer_Tick();
                }
            }
        }

        private void Timer_Tick()
        {
            if (this.InvokeRequired)
            {
                this.Invoke(new Action(Timer_Tick));
                return;
            }

            MoveRectangle();
            CheckCollisions();
            this.Invalidate(); // Trigger the Paint event to redraw the shape
        }

        private void MoveRectangle()
        {
            rectangle1.X += dx1;
            rectangle2.X += dx2;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "Collapses " + collapses.ToString();
        }

        private void CheckCollisions()
        {
            float width1 = rectangle1.Width;
            float width2 = rectangle2.Width;

            // Check collision with the left and right edges
            if (rectangle1.X <= 0)
            {
                collapses++;
                dx1 = -dx1; // Reverse direction
            }

            if (rectangle2.X <= 0)
            {
                dx2 = -dx2; // Reverse direction
            }

            // Check collision between rectangles
            if (rectangle1.IntersectsWith(rectangle2))
            {
                collapses++;

                float d11 = ((weight1 - weight2) * dx1 + 2 * weight2 * dx2) / (weight1 + weight2);
                float d12 = ((weight2 - weight1) * dx2 + 2 * weight1 * dx1) / (weight2 + weight1);

                dx1 = d11;
                dx2 = d12;
            }
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.FillRectangle(Brushes.Blue, rectangle1.X, rectangle1.Y, rectangle1.Width, rectangle1.Height);
            g.FillRectangle(Brushes.Green, rectangle2.X, rectangle2.Y, rectangle2.Width, rectangle2.Height);
        }
    }
}
